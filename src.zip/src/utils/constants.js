const constant = {
  DVP_DOCS_URL: "https://dvpdocs.optum.com",
  DVP_USER_GUIDE_URL: "https://dvpdocs.optum.com/capability/trydvp/TryDVP.html",
  DATA_VALIDATION_PLATFORM: "Data Validation Platform",
  SOURCE_DB: "Source DB:",
  PREVIOUS_SOURCE_DB: "Previous Source DB:",
  REPORT_GENERATED: "Report Generated On:",
  EVAL_RUN_ID: "Eval Run Id:",
  CLIENT_ID: "Client ID:",
  BUILD_VALUE: "Build Value:",
  DATAVERSION: "Dataversion:",
  ACTION_SUMMARY:
    "Action summary is automatically populated based on actions taken for DVP Execution Failures.",
  LOADER_TEXT: "Information loading, please wait...",
  TABLE_HEADER_MESSAGE:
    "By default, recurring failures are marked as 'Ignore'. Review them to make manual changes.",
  EVAL_FAILURES: "eval_failures",
  EVAL_RUN: "eval_run",
  MIXED_VALUE: "Mixed action value present for selected items.",
  IGNORED: "ignored",
  MARKED_FOR_RERUN: "marked for rerun",
  UNSAVED_CHANGES: "You have unsaved changes",
  UNSAVED_CHANGES_MSG:
    "The page contains unsaved changes. Save changes to avoid any data loss.",
  STAY_ON_PAGE: "Stay on page",
  LEAVE_PAGE: "Leave page",
  SERVER_ERROR: "Server Error. Cannot load data.",
  NUMBER_OF_RECORDS: "Number of rows",
  READY_FOR_REVIEW: "Ready for review",
  DISAPPROVED: "Disapproved",
  REJECTED: "Rejected",
  APPROVED: "Approved",
  RESET_HOVER_MSG_1: "Reset will set filters to default as below:",
  RESET_HOVER_MSG_2: "1. Past 6 months of DVP reports will be shown. ",
  RESET_HOVER_MSG_3: "2. Ready for review reports will be selected.",
  SELECT_ALL: "select-all",
  LOGOUT: "logout",
  SESSION_EXPIRED_MESSAGE: "Your session have timed-out! Kindly login again.",
  CONTENT_CHECK_API: "content_check",
  CONTENT_CHECK: "Content Check",
  FACILITY_CLIENT_NAME: "Facility/Client Name",
  REPORT_CREATION_DATE: "Date of Report Creation",
  CONTENT_CHECK_TABLE_INFO: "Failed views are highlighted in red color.",
  EXPORT_CSV: "Export as CSV",
  AI_CHECK_CONSTANT: "1",
  EVAL_RESULT: "eval_result",
  ROOT_FILTER: "root_filter",
  NO_CHARTS_PRESENT: "No charts present for applied filters.",
  DATE_FORMAT: "DD/MM/YYYY",
  AI_CHART_INFO:
    "Upper and Lower bound values are not applicable for data load count less than 3",
  CORE_RULES: "Core Rule",
  NO_DATA: "No data available",
};

const saveConstants = {
  SAVE_CHANGES: "Save Changes",
  IN_PROGRESS: "Saving changes. Please wait.",
  SUCCESSS: "Changes have been successfully saved.",
  ERROR: "Changes were not saved. Please try again.",
  APPROVED: "QC successfully marked as approved.",
  DISAPPROVED: "QC successfully marked as disapproved.",
};

const workflow = {
  EXECUTION_FAILURE: "DVP Execution Failure",
  ANALYSE_CHART: "Analyse Charts",
  QC_SIGNOFF: "QC Signoff",
};

const reportStatus = {
  APPROVED: "approved",
  REJECTED: "rejected",
};

const navigationTabs = {
  AI_CHECK_RESULTS: "AI Check Results",
  CONTENT_CHECK_RESULTS: "Content Check Results",
  SUMMARY: "Summary",
};

const chartTypes = {
  CLASSDIST_ANALYSIS: "classdistanalysis",
  RATE_ANALYSIS: "rateanalysis",
  THRESHOLD_ANALYSIS: "thresholdanalysis",
};

const toastConstants = {
  ERROR: "error",
  SUCCESS: "success",
  INVALID_URL: "Invalid URL",
  REDIRECTED_DASHBOARD: "Redirected to dashboard",
  EVAL_RUN_NOT_FOUND: "Run Details Not Available",
  CONTENT_CHECK_MISSING: "Content Check Results Not Available",
  ERROR_UPDATING_RECORDS: "Error updating records",
  AI_CHECK_MISSSING: "AI Check Results Not Available",
  BAD_ROWS_FROM_GREATER_THAN_TO:
    "'Bad Rows % from' should be less than 'Bad Rows % to'",
  BAD_ROWS_RANGE: "Bad row % should be from 0 to 100",
};

export {
  chartTypes,
  constant,
  navigationTabs,
  reportStatus,
  saveConstants,
  toastConstants,
  workflow,
};
