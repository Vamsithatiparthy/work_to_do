import React, { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { SelectInput } from "@abyss/web/ui/SelectInput";
import { LoadingIndicator, Pagination } from "@uitk/react";
import PropTypes from "prop-types";

import Chart from "../../components/chart/Chart.js";
import { constant } from "../../utils/constants.js";

import { useGetEvalResultsMutation } from "./analyseChartApiSlice.js";
import { setPage, setPageLimit } from "./analyseChartSlice.js";
import { transformEvalChartsRespnse } from "./transformApiResponse.js";

function ChartList({ evalId }) {
  const [sortBySeverity, setSortBySeverity] = useState("desc:severity");
  const [loading, setLoading] = useState(false);

  const [getEvalCharts, { data: evalResults, isLoading }] =
    useGetEvalResultsMutation();
  const { filters, page, limit } = useSelector((state) => state.analyseChart);
  const dispatch = useDispatch();

  useEffect(() => {
    setLoading(true);
    getEvalChartsAndEvalResults();
  }, [page, limit, sortBySeverity, filters]);

  useEffect(() => {
    if (evalResults?.eval_results?.length === 0) {
      setLoading(false);
    }
  }, [evalResults]);

  const getEvalResultsMutationBody = () => {
    let appliedFilters = [];
    const mapFilterKeys = {
      rule: "rule",
      modelName: "model_name",
      columnName: "column_name",
      ruleName: "rule_name",
      flaggedStatus: "flagged_status",
      partitionGranularity: "partition_granularity",
      checkTags: "check_tags",
    };
    for (const [key, value] of Object.entries(filters)) {
      if (
        key != "includeSeverity" &&
        key != "includeCore" &&
        value.length !== 0
      )
        appliedFilters.push({
          key: mapFilterKeys[key],
          values: value,
        });
    }
    return {
      nullseverity: filters.includeSeverity,
      isCore: filters.includeCore,
      page: page,
      limit: parseInt(limit),
      filters: appliedFilters,
      sort: sortBySeverity,
    };
  };

  const getEvalChartsAndEvalResults = () => {
    getEvalCharts({
      id: evalId,
      data: getEvalResultsMutationBody(),
    });
  };

  const evalCharts = useMemo(
    () => transformEvalChartsRespnse(evalResults?.eval_results),
    [evalResults]
  );

  const paginationConfig = {
    pageSize: 10,
    totalItemsCount: evalResults?.total,
    enableGotoPage: true,
  };

  const entriesPerPageConfig = {
    pageSizeOptions: [
      {
        label: "10",
        value: 10,
      },
      {
        label: "25",
        value: 25,
      },
      {
        label: "50",
        value: 50,
      },
    ],
    initialValue: 10,
  };

  const onPageChange = (newPage) => {
    dispatch(setPage(newPage));
  };

  const loadEvalCharts = useMemo(() => {
    return evalCharts?.map((element, index) => {
      return <Chart key={index} setLoading={setLoading} chartData={element} />;
    });
  }, [evalCharts]);

  if (!isLoading && evalCharts?.length === 0) {
    return (
      <p className="font-semibold mt-4 text-lg h-[68vh]">
        {constant.NO_CHARTS_PRESENT}
      </p>
    );
  }

  return (
    <>
      <Pagination
        id="pagination-entries"
        config={paginationConfig}
        entriesPerPageConfig={entriesPerPageConfig}
        onPageChange={onPageChange}
        page={page}
      >
        {({ pageSize }) => {
          if (pageSize !== limit) {
            dispatch(setPageLimit(pageSize));
            setLoading(true);
          }
          return (
            <>
              <div className="flex justify-between items-center">
                <p>
                  Displayed Items: <span>{evalResults?.total}</span>
                </p>
                <div className="flex items-center pb-4">
                  <p className="mr-3 w-[130px] font-bold">Sort By Severity</p>
                  <SelectInput
                    width="160px"
                    placeholder="Pick one"
                    value={sortBySeverity}
                    onChange={(value) => setSortBySeverity(value)}
                    options={[
                      { value: "desc:severity", label: "Descending" },
                      { value: "asc:severity", label: "Ascending" },
                    ]}
                  />
                </div>
              </div>
              {loading && (
                <LoadingIndicator
                  size={"l"}
                  loading={loading}
                  centerSpinner={true}
                  displayOverlay={true}
                  loadingText={"Loading..."}
                  className="global-loading-indicator"
                />
              )}
              <div className="">{loadEvalCharts}</div>
            </>
          );
        }}
      </Pagination>
    </>
  );
}

ChartList.propTypes = {
  evalId: PropTypes.string,
};
export default ChartList;
