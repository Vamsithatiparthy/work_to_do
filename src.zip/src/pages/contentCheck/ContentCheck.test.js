import React from "react";
import { act, fireEvent, screen, waitFor } from "@testing-library/react";
import { Toolkit } from "@uitk/react";
import Papa from "papaparse";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";
import * as commonUtils from "../../utils/common";

import ContentCheck from "./ContentCheck";

let component = null;
beforeEach(async () => {
  await act(async () => {
    component = renderWithProviders(
      <Toolkit>
        <ContentCheck />
      </Toolkit>
    );
  });
});

afterEach(() => {
  component.unmount();
});

jest.mock("papaparse", () => ({
  unparse: jest.fn(),
}));

global.URL.createObjectURL = jest.fn();

describe("Renders Content Check page correctly", () => {
  test("Renders Content Check page correctly", async () => {
    await waitFor(() => {
      expect(screen.getByTestId(/content-check-page/i)).toBeInTheDocument();
    });
  });
});

describe("Renders Content Check table correctly", () => {
  test("Renders Content Check table correctly", async () => {
    await waitFor(() => {
      expect(screen.getByTestId(/content-check-table/i)).toBeInTheDocument();
    });
  });

  test("Renders nested table when row is expanded", async () => {
    const expandRow = await screen.findAllByTestId("Expand Row");
    await waitFor(() => {
      fireEvent.click(expandRow[0]);
    });
    await waitFor(() => {
      expect(screen.getByTestId(/nested-table/i)).toBeInTheDocument();
    });
  });

  test("Renders table row with background color RED for unaccepted achecks.", async () => {
    const tableRows = await screen.findAllByTestId("table-row");
    const firstRow = tableRows[0];
    await waitFor(() => {
      expect(firstRow.childNodes[2].firstChild.className).toEqual(
        "content-check-accept"
      );
    });
  });

  describe("Renders Content Check table correctly", () => {
    test("generates and downloads a CSV file", async () => {
      const button = await screen.findByTestId("generate-csv");

      const csvData = [
        ["Name", "Email", "Phone"],
        ["John Doe", "john@example.com", "1234567890"],
        ["Jane Smith", "jane@example.com", "0987654321"],
      ];

      Papa.unparse.mockReturnValue("csv content");

      // Mock the entire commonUtils module
      jest
        .spyOn(commonUtils, "generateAndDownloadCSV")
        .mockImplementation(() => {
          // Mock implementation of generateAndDownloadCSV function
          // below unused variable is needed to call unparse method once
          /*eslint-disable*/
          const csv = Papa.unparse(csvData);

          const url = "mock-download-url";
          global.URL.createObjectURL.mockReturnValue(url);

          const link = document.createElement("a");
          link.href = url;
          link.download = "data.csv";
          link.click();
        });
      fireEvent.click(button);

      expect(commonUtils.generateAndDownloadCSV).toHaveBeenCalled();
      expect(Papa.unparse).toHaveBeenCalledWith(csvData);
    });
  });
});

describe("Content check filters working correctly", () => {
  test("View Name filter works correctly", async () => {
    const viewNameFilter = await screen.findByTestId(
      "view-name-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(viewNameFilter);
    const selectClaim = await screen.findAllByTestId(
      "view-name-filter-abyss-select-input-multi-option-checkbox"
    );
    fireEvent.click(selectClaim[1]);
    const applyBtn = await screen.findByTestId(
      "content-check-filter-apply-btn"
    );
    fireEvent.click(applyBtn);
    const tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(1);
  });

  test("Check Name filter works correctly", async () => {
    const checkNameFilter = await screen.findByTestId(
      "check-name-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(checkNameFilter);
    const selectCheck = await screen.findAllByTestId(
      "check-name-filter-abyss-select-input-multi-option-checkbox"
    );
    fireEvent.click(selectCheck[1]);
    const applyBtn = await screen.findByTestId(
      "content-check-filter-apply-btn"
    );
    fireEvent.click(applyBtn);
    const tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(1);
  });

  test("Bad rows filter works correctly", async () => {
    const badRowsFromFilter = await screen.findByTestId(
      "bad-rows-from-filter-abyss-text-input"
    );
    const badRowsToFilter = await screen.findByTestId(
      "bad-rows-to-filter-abyss-text-input"
    );
    fireEvent.change(badRowsFromFilter, {
      target: {
        value: "10",
      },
    });
    fireEvent.change(badRowsToFilter, {
      target: {
        value: "40",
      },
    });
    const applyBtn = await screen.findByTestId(
      "content-check-filter-apply-btn"
    );

    fireEvent.click(applyBtn);
    const tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(8);
  });
});
