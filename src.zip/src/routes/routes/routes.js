import React, { Suspense, useEffect } from "react";
import { Redirect, Route, Switch, useHistory } from "react-router-dom";
import { toast } from "@abyss/web/ui/Toast";
import { LoadingIndicator } from "@uitk/react";

import Dashboard from "../../pages/dashboard/Dashboard";
import Overview from "../../pages/overview/OverviewPage";
import { toastConstants } from "../../utils/constants";
const DvpReport = React.lazy(() => import("../../pages/results/DvpReport"));
// matches the pattern for URL path for DVP runs
// /dvpRuns/clientId/:clientId/env/:env/level/:level/version/:version
const dvpRunsPathPattern =
  /^\/dvpRuns\/clientId\/[^/]+\/env\/[^/]+\/level\/[^/]+\/version\/[^/]+$/;

function Routes() {
  const history = useHistory();

  useEffect(() => {
    const currentPath = history.location.pathname;
    if (
      currentPath !== "/" &&
      currentPath !== "/dashboard" &&
      currentPath !== "/overview" &&
      !dvpRunsPathPattern.test(currentPath)
    ) {
      if (currentPath !== "/dashboard/") {
        toast.show({
          title: toastConstants.INVALID_URL,
          message: toastConstants.REDIRECTED_DASHBOARD,
          type: toastConstants.ERROR,
        });
      }

      history.push("/dashboard");
    }
  }, [history]);

  return (
    <Switch>
       <Route exact path="/">
       <Redirect to="/overview" />
        <Dashboard />
      </Route>
      <Route exact path="/dashboard">
        <Dashboard />
      </Route>
      <Route exact path="/overview">
        <Overview />
      </Route>
      <Suspense
        fallback={
          <LoadingIndicator
            size={"l"}
            centerSpinner={true}
            displayOverlay={true}
            loadingText={"Loading..."}
            className="global-loading-indicator"
          />
        }
      >
        <Route
          exact
          path="/dvpRuns/clientId/:clientId/env/:env/level/:level/version/:version"
        >
          <DvpReport />
        </Route>
      </Suspense>
      <Route path="*">
        <Redirect to="/dashboard" />
      </Route>
    </Switch>
  );
}

export default Routes;
