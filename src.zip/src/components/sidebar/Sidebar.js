import { Navigation, NavType } from "@uitk/react";
import {
  ArrowDown,
  ArrowUp,
  Document,
  Guidelines,
  HelpHollow,
  NewWindow,
  Results,
} from "@uitk/react-icons";

import { RoutableLink } from "../../utils/common";
import { constant } from "../../utils/constants";

const useCurrentRoute = () => {
  const location = window.location.pathname;
  return location;
};

function Sidebar() {
  const dashboard = {
    label: "Reports",
    url: "/dashboard",
    icon: <Results customSize="24px" />,
  };
  // const rules = {
  //   label: <span id="write-rules">Write Rules</span>,
  //   url: "/rules",
  //   icon: <Edit customSize="24px" />,
  // };
  const help = {
    label: "Help",
    icon: <HelpHollow customSize="24px" />,
    links: [
      {
        label: (
          <>
            About DVP
            <br />
            <NewWindow />
          </>
        ),
        url: constant.DVP_DOCS_URL,
        target: "_blank",
        icon: (
          <>
            <Guidelines customSize="24px" />
          </>
        ),
      },
      {
        label: (
          <>
            User Guide
            <br />
            <NewWindow />
          </>
        ),
        target: "_blank",
        url: constant.DVP_USER_GUIDE_URL,
        icon: (
          <>
            <Document customSize="24px" />
          </>
        ),
      },
    ],
  };
  //const navigationLink = [dashboard, rules, help];
  const navigationLink = [dashboard, help];
  const verticalNavigationConfig = {
    linkAs: RoutableLink,
    links: navigationLink,
    panelExpandedIcon: <ArrowUp />,
    panelClosedIcon: <ArrowDown />,
  };

  return (
    <div className={"sidebar"} data-testid="sidebar">
      <Navigation
        useLocation={useCurrentRoute}
        className="vertical-navigation"
        variant={NavType.VERTICAL}
        config={verticalNavigationConfig}
      />
    </div>
  );
}

export default Sidebar;
