import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { useToast } from "@abyss/web/hooks/useToast";
import { Button, LoadingIndicator } from "@uitk/react";
import PropTypes from "prop-types";

import { toggleLoading } from "../../app/appSlice";
import ProgressWizard from "../../components/progressWizard/ProgressWizard";
import RouterPrompt from "../../components/RouterPrompt/RouterPrompt";
import Snackbar from "../../components/snackbar/Snackbar";
import AnalyseChart from "../../features/analyseChart/AnalyseChart";
import {
  selectEvalFailures,
  selectUpdatedEvalFailures,
  setEvalFailures,
} from "../../features/executionFailure/evalFailuresSlice";
import { resetUpdateFlageOnEvalFailures } from "../../features/executionFailure/evalFailuresSlice";
import ExecutionFailure from "../../features/executionFailure/ExecutionFailure";
import {
  constant,
  saveConstants,
  toastConstants,
  workflow,
} from "../../utils/constants";

import {
  useGetExecutionFailuresQuery,
  useGetReportBaseUrlQuery,
  useUpdateExecutionFailuresMutation,
} from "./evalReportApiSlice";
import {
  showAlert,
  toggleSaveChanges,
  updateStepButtons,
} from "./evalReportSlice";

function EvalReport({ report_details, currentDataVersion }) {
  const { toast } = useToast();
  const { data: baseUrl, isLoading: isBaseUrlLoading } =
    useGetReportBaseUrlQuery();

  const evalRunClicked = JSON.parse(localStorage.getItem("evalRunClicked"));
  const evalId = report_details.eval_runs.ai.find(
    (item) => item.dataVersion === currentDataVersion
  ).evalId;
  const { data: evalRunDetails, isLoading: isEvalRunDetailsLoading } =
    report_details;
  const [step, setStep] = useState({
    currentStep: 1,
  });
  const {
    data: evalFailures,
    isLoading,
    error,
    isError,
  } = useGetExecutionFailuresQuery(evalId);
  const [updateExecutionFailures] = useUpdateExecutionFailuresMutation();
  const { saveChangesEnabled, snackBar, enablePrevStep } = useSelector(
    (state) => state.evalReport
  );
  const updatedEvalFailures = useSelector(selectUpdatedEvalFailures);
  const { isFiltersOpen } = useSelector((state) => state.analyseChart);
  const evalFailuresData = useSelector(selectEvalFailures);
  const dispatch = useDispatch();
  const { loader } = useSelector((state) => state.app);
  const [wizardSteps, setWizardSteps] = useState([
    workflow.EXECUTION_FAILURE,
    workflow.ANALYSE_CHART,
  ]);
  const [alertTimeoutID, setAlertTimeoutID] = useState(undefined);
  const history = useHistory();
  useEffect(() => {
    return () => {
      dispatch(toggleSaveChanges(false));
    };
  }, []);
  // after changing the version, reset the current step to 1
  useEffect(() => {
    setStep({ currentStep: 1 });
  }, [currentDataVersion]);

  useEffect(() => {
    if (isError && error) {
      toast.show({
        title: toastConstants.AI_CHECK_MISSSING,
        type: toastConstants.ERROR,
      });
      goToDvpReport();
      history.goBack();
    }
    if (
      !isLoading &&
      !isEvalRunDetailsLoading &&
      !isBaseUrlLoading &&
      evalFailures
    ) {
      if (evalFailures.length !== 0) {
        initialSetup();
        saveChanges(evalFailures);
      }
    }
  }, [isLoading, isEvalRunDetailsLoading, isBaseUrlLoading, isError]);

  const goToDvpReport = () => {
    const { clientid, version, data_version, level } =
      evalRunDetails || evalRunClicked;
    const reportUrl = `${baseUrl.cdnUrl}/${version}/${level}/${clientid}/${data_version}/${clientid}_${level}_${version}_${data_version}_periodicrefresh/index.html`;
    window.open(reportUrl, "_blank");
  };

  const initialSetup = () => {
    if (evalFailures?.length == 0) {
      setWizardSteps(wizardSteps.slice(1));
    } else {
      if (anyNullFailureAction(evalFailures)) {
        dispatch(
          updateStepButtons({ enableNextStep: true, enablePrevStep: false })
        );
      }
    }
  };

  const anyNullFailureAction = (records) => {
    return records.filter((data) => data.failure_action === null).length === 0;
  };

  const setAlert = ({ show, message, variant }) => {
    clearTimeout(alertTimeoutID);
    dispatch(showAlert({ show, message, variant }));
    setAlertTimeoutID(
      setTimeout(() => {
        dispatch(showAlert({ show: false }));
      }, 4000)
    );
  };

  const stepSelection = (currentStep, stepClicked) => {
    if (currentStep === stepClicked) {
      return;
    }

    if (wizardSteps[currentStep - 1] === workflow.EXECUTION_FAILURE) {
      /* Below code to be uncommented when its mandatory to fill all failure actions to move ahead */
      const records = evalFailuresData.map((evalFailure) =>
        evalFailure.failure_action === null
          ? {
              ...evalFailure,
              error: true,
            }
          : evalFailure
      );

      if (records.filter((data) => data.error === true).length > 0) {
        const steps = wizardSteps
          .slice(currentStep - 1, stepClicked - 1)
          .join(" and ");
        dispatch(setEvalFailures(records));
        setAlert({
          show: true,
          message:
            "Fill action for " +
            steps +
            " to proceed to " +
            wizardSteps[stepClicked - 1],
          variant: "error",
        });
      } else if (saveChangesEnabled) {
        setAlert({
          show: true,
          message: "Save changes to proceed to " + wizardSteps[stepClicked - 1],
          variant: "error",
        });
      } else {
        setStep({ currentStep: stepClicked });
        dispatch(
          updateStepButtons({ enablePrevStep: true, enableNextStep: true })
        );
      }
    } else {
      setStep({ currentStep: stepClicked });
    }
  };

  const saveChanges = async (evalFailures = []) => {
    dispatch(
      toggleLoading({
        isLoading: true,
        loadingText: evalFailures?.length > 0 ? "" : saveConstants.IN_PROGRESS,
      })
    );
    const evalID = evalRunClicked?.id;
    let changedEvalFailures = updatedEvalFailures;
    if (evalFailures?.length > 0) {
      changedEvalFailures = evalFailures.filter(
        (evalFailure) => evalFailure["updated"] == true
      );
    }
    const records = changedEvalFailures.map((evalFailure) => {
      return {
        id: evalFailure.id,
        failure_action: evalFailure.failure_action,
      };
    });

    if (records.length != 0) {
      try {
        await updateExecutionFailures({
          evalID: evalID,
          updatedEvalFailures: records,
        }).unwrap();

        if (!evalFailures?.length > 0) {
          setAlert({
            show: true,
            message: saveConstants.SUCCESSS,
            variant: "success",
          });
          dispatch(toggleSaveChanges(false));
          dispatch(resetUpdateFlageOnEvalFailures());
          if (anyNullFailureAction(evalFailuresData)) {
            dispatch(
              updateStepButtons({ enablePrevStep: false, enableNextStep: true })
            );
          }
        }
      } catch {
        setAlert({
          show: true,
          message: saveConstants.ERROR,
          variant: "error",
        });
      }
    }

    dispatch(toggleLoading({ isLoading: false, loadingText: "" }));
  };

  const resetSnackBar = () => {
    dispatch(showAlert({ show: false }));
  };

  return (
    <>
      <div className="eval-report">
        {loader.isLoading && (
          <LoadingIndicator
            size={"l"}
            loading={loader.isLoading}
            centerSpinner={true}
            displayOverlay={true}
            loadingText={loader.loadingText}
            className="global-loading-indicator"
          />
        )}
        <Snackbar
          show={snackBar.show}
          message={snackBar.message}
          variant={snackBar.variant}
          closeCallback={resetSnackBar}
        ></Snackbar>

        {(isLoading || isEvalRunDetailsLoading) && (
          <LoadingIndicator
            size={"l"}
            loading={isLoading}
            centerSpinner={true}
            className="eval-report-loader"
            loadingText={constant.LOADER_TEXT}
          />
        )}
        {!isLoading && (
          <>
            <div className="eval-report-wizard row">
              <ProgressWizard
                currentStep={step.currentStep}
                steps={wizardSteps}
                onClick={stepSelection}
              />
            </div>
            {wizardSteps[step.currentStep - 1] ===
              workflow.EXECUTION_FAILURE && (
              <>
                <ExecutionFailure
                  evalFailures={evalFailures}
                  saveChanges={saveChanges}
                />
              </>
            )}
            {wizardSteps[step.currentStep - 1] === workflow.ANALYSE_CHART && (
              <AnalyseChart evalId={evalId} />
            )}
            <div
              className={`${
                isFiltersOpen ? "!ml-[26.5%]" : ""
              } eval-step-actions`}
            >
              <div>
                {step.currentStep != 1 && (
                  <Button
                    disabled={!enablePrevStep}
                    onPress={() =>
                      stepSelection(step.currentStep, step.currentStep - 1)
                    }
                  >
                    {`< Previous`}
                  </Button>
                )}
              </div>
              {/* Always enabled next button */}
              <div>
                {step.currentStep != 2 && (
                  <Button
                    onPress={() =>
                      stepSelection(step.currentStep, step.currentStep + 1)
                    }
                  >
                    {`Next >`}
                  </Button>
                )}
              </div>
            </div>
          </>
        )}
      </div>
      <RouterPrompt
        when={saveChangesEnabled}
        title={constant.UNSAVED_CHANGES}
        content={constant.UNSAVED_CHANGES_MSG}
        variant={"warning"}
        history={history}
      />
    </>
  );
}

EvalReport.propTypes = {
  report_details: PropTypes.object,
  currentDataVersion: PropTypes.string,
};

export default EvalReport;
