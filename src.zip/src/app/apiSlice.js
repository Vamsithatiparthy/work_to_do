import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import Cookies from "js-cookie";

import { getAppUrl } from "../utils/common";

export const apiSlice = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({
    baseUrl: getAppUrl(),
    credentials: "include",
    prepareHeaders: (headers) => {
      headers.set("X-XSRF-TOKEN", Cookies.get("XSRF-TOKEN"));
      return headers;
    },
  }),
  tagTypes: ["EvalFailure", "EvalRunId"],
  endpoints: () => ({}),
});
