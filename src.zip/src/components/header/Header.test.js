import React from "react";
import { render } from "@testing-library/react";
import { act, waitFor } from "@testing-library/react";
import { screen } from "@testing-library/react";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";
import userMockData from "../../utils/mockdata/userDetails";

import Header from "./Header";

let component = null;
beforeEach(async () => {
  await act(async () => {
    component = renderWithProviders(
      <Toolkit>
        <Header userDetails={userMockData} />
      </Toolkit>
    );
  });
});

describe("Renders Header Component correctly", () => {
  test("Renders Header Component correctly", async () => {
    await waitFor(() => {
      expect(
        screen.getAllByText(/Data Validation Platform/i)[0]
      ).toBeInTheDocument();
    });
  });
});
