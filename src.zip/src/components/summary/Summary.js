import React from "react";
import PropTypes from "prop-types";

function Summary({ summaryProps }) {
  const summaryData = summaryProps();

  // This function shows Total record details if any
  const showTotalRecords = (element, details) => {
    return (
      <>
        {element?.totalRecords?.key && (
          <div
            className={`summaryTotal ${
              element?.totalRecords?.key && Object.keys(details).length > 0
                ? "summaryTotalVerticalLine"
                : ""
            }`}
          >
            <p>{element?.totalRecords?.key}</p>
            <p>{element?.totalRecords?.value}</p>
          </div>
        )}
      </>
    );
  };

  // This function shows all record details block
  const showDetails = (element, details) => {
    return (
      <div className="summaryDetails">
        {showTotalRecords(element, details)}
        {Object.keys(details).map((ele, index) => {
          const key = ele;
          const value = details[ele];
          return (
            <React.Fragment key={index}>
              <div className="summaryBlock">
                <p>{key}</p>
                {value != 0 && <p className="summaryCount">{value}</p>}
                {value == 0 && <p className="summaryCount">-</p>}
              </div>
            </React.Fragment>
          );
        })}
      </div>
    );
  };
  return (
    <div className="summary row">
      {summaryData.map((element, index) => {
        const details = element.details;
        return (
          <div key={index} className={`summarySection `}>
            <p className="summarySectionHeader">
              {element.header}
              {element.icon}
            </p>
            {showDetails(element, details)}
          </div>
        );
      })}
    </div>
  );
}

Summary.propTypes = {
  summaryProps: PropTypes.func,
};

export default Summary;
