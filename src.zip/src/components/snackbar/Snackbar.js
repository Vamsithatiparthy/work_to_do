import { Alert } from "@abyss/web/ui/Alert";
import PropTypes from "prop-types";

function Snackbar(props) {
  return (
    <>
      {" "}
      <Alert
        title={props.message}
        variant={props.variant}
        className="alert-box"
        isVisible={props.show}
        onClose={() => {
          props.closeCallback();
        }}
      ></Alert>
    </>
  );
}
Snackbar.propTypes = {
  show: PropTypes.bool,
  message: PropTypes.string,
  variant: PropTypes.string,
  closeCallback: PropTypes.func,
};
export default Snackbar;
