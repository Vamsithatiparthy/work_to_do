const ruleTypeFilter = {
  name: "rule",
  data: [
    { value: "rateanalysis" },
    { value: "timeseriesanalysis" },
    { value: "classdistanalysis" },
  ],
};

const clientDsIdFilter = {
  name: "partition_granularity.client_ds_id",
  data: [
    { value: "20121" },
    { value: "1023" },
    { value: "3535" },
    { value: "65465" },
    { value: "4343" },
  ],
};

export { clientDsIdFilter, ruleTypeFilter };
