import React from "react";
import { Button } from "@uitk/react";
import PropTypes from "prop-types";

import reject from "../../assets/cancel.svg";
import approve from "../../assets/tickIcon.svg";
import { formatDateTime } from "../../utils/common";
import { reportStatus } from "../../utils/constants";

function ReportStatusBar({
  currentEvalRunData,
  openModalHandler,
  dataVersion,
}) {
  const report_status = currentEvalRunData?.review_details?.review_outcome;
  const reviewed_by = currentEvalRunData?.review_details?.reviewed_by;
  const reviewed_on = formatDateTime(
    currentEvalRunData?.review_details?.reviewed_on
  );
  const reportGeneratedDate = formatDateTime(currentEvalRunData?.created_on);
  const reportStatusIcon =
    report_status === reportStatus.REJECTED ? reject : approve;
  const status =
    report_status === reportStatus.APPROVED
      ? "Approved"
      : report_status === reportStatus.REJECTED
      ? "Rejected"
      : null;
  return (
    <>
      <div className="reportStatusBar">
        <div className="reportDetails">
          <div className="reportDetails">
            <table className="report-table">
              <tbody>
                <tr>
                  <td>
                    <b>Client ID:</b> {currentEvalRunData.client.toUpperCase()}
                  </td>
                  <td>
                    <b>Environment:</b> {currentEvalRunData.env.toUpperCase()}
                  </td>
                  <td>
                    <b>Level:</b> {currentEvalRunData.level.toUpperCase()}
                  </td>
                </tr>
                <tr>
                  <td>
                    <b>Build Value:</b> {currentEvalRunData.version}
                  </td>
                  <td>
                    <b>Version:</b> {dataVersion}
                  </td>
                  <td>
                    <b>Report Generated On:</b> {reportGeneratedDate}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="reportStatus">
          {(report_status === reportStatus.APPROVED ||
            report_status === reportStatus.REJECTED) && (
            <div className="status-message">
              <img className="report-icon" src={reportStatusIcon} />
              <b>{status}</b> by {reviewed_by} on {reviewed_on}
            </div>
          )}
          {report_status == null && (
            <>
              <Button
                size="s"
                id="btn-approve"
                onClick={() => openModalHandler(reportStatus.APPROVED)}
              >
                Approve
              </Button>
              <Button
                size="s"
                id="btn-reject"
                onClick={() => openModalHandler(reportStatus.REJECTED)}
              >
                Reject
              </Button>
            </>
          )}
        </div>
      </div>
    </>
  );
}

ReportStatusBar.propTypes = {
  currentEvalRunData: PropTypes.object,
  openModalHandler: PropTypes.func,
  dataVersion: PropTypes.string,
};

export default ReportStatusBar;
