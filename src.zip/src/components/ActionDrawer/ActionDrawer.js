import React from "react";
import { useSelector } from "react-redux";
import { Button } from "@uitk/react";
import { Contract, Expand, WarningFilled } from "@uitk/react-icons";
import PropTypes from "prop-types";

import { constant } from "../../utils/constants";

const ActionDrawer = ({
  open,
  content,
  setIsOpen,
  checkedCount,
  onApply,
  disabled,
  mixedValue,
}) => {
  const { actionBtnHeight } = useSelector((state) => state.evalFailures);

  return (
    <>
      <div
        onClick={() => setIsOpen(!open)}
        className={`${
          actionBtnHeight >= 580 ? "action-popout" : ""
        } table-header-right`}
        data-testid="execution-failure-action-btn"
      >
        <p>Actions</p>
        <span>
          <Expand />
        </span>
      </div>

      <div className={`sidebar-drawer ${open ? "open" : ""}`}>
        {open && (
          <div className="action-drawer" data-testid="action-drawer">
            <div className="action-drawer-header">
              <p>Actions</p>
              <Contract
                className="action-drawer-contract"
                onClick={() => setIsOpen(!open)}
              />
            </div>
            <p className="action-items-count">{checkedCount} items selected</p>
            {mixedValue && (
              <div className="mixed-value" data-testid="mixed-value">
                <div className="mixed-value-content">
                  <span>
                    <WarningFilled />
                  </span>
                  <p>{constant.MIXED_VALUE}</p>
                </div>
              </div>
            )}
            {content()}
            <div className="action-buttons">
              <Button
                onClick={onApply}
                className="action-apply-btn"
                data-testid="action-apply-btn"
                disabled={disabled}
              >
                Apply
              </Button>
              <Button
                disabled={disabled}
                data-testid="action-cancel-btn"
                onClick={() => setIsOpen(false)}
                variant="ghost"
              >
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

ActionDrawer.propTypes = {
  open: PropTypes.bool,
  setIsOpen: PropTypes.func,
  content: PropTypes.func,
  checkedCount: PropTypes.number,
  onApply: PropTypes.func,
  disabled: PropTypes.bool,
  mixedValue: PropTypes.bool,
  actionBtnHeight: PropTypes.number,
};

export default ActionDrawer;
