import { createEntityAdapter, createSlice } from "@reduxjs/toolkit";

const analyseChartAdapter = createEntityAdapter();
const initialState = analyseChartAdapter.getInitialState({
  isFiltersOpen: false,
  filters: {
    rule: [],
    modelName: [],
    columnName: [],
    ruleName: [],
    flaggedStatus: [],
    checkTags: [],
    includeSeverity: true,
    includeCore: false,
  },
  page: 1,
  limit: 10,
});

const analyseChartSlice = createSlice({
  name: "analyseChart",
  initialState,
  reducers: {
    setIsFiltersOpen(state, action) {
      state.isFiltersOpen = action.payload;
    },
    updateFilters(state, action) {
      state.filters = {
        ...state.filters,
        rule: action.payload.rule,
        modelName: action.payload.modelName,
        columnName: action.payload.columnName,
        ruleName: action.payload.ruleName,
        checkTags: action.payload.checkTags,
        flaggedStatus: action.payload.flaggedStatus,
        includeSeverity: action.payload.includeSeverity,
        includeCore: action.payload.includeCore,
      };
    },
    setPage(state, action) {
      state.page = action.payload;
    },
    setPageLimit(state, action) {
      state.limit = action.payload;
    },
  },
});

export const { updateFilters, setIsFiltersOpen, setPage, setPageLimit } =
  analyseChartSlice.actions;
export default analyseChartSlice.reducer;
