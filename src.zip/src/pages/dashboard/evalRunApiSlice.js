import moment from "moment";

import { apiSlice } from "../../app/apiSlice";
import { constant } from "../../utils/constants";

export const evalRunApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getEvalRunDetails: builder.query({
      query: (param) => {
        return {
          url: `dvp?type=${param}`,
        };
      },
      transformResponse: async (response) => {
        const data = response;
        return {
          unStructuredEvalResults: response,
          structuredEvalResults: data.sort((a, b) => sortEvalRun(a, b, -1)),
        };
      },
    }),
    getData: builder.query({
      query: ({ clientId, env, level, version }) =>
        `dvpRuns/clientId/${clientId}/env/${env}/level/${level}/version/${version}`,
    }),
  }),
});

function sortEvalRun(a, b, sortDirection) {
  if (a.version < b.version) {
    return -sortDirection;
  } else if (a.version > b.version) {
    return sortDirection;
  } else {
    if (
      new Date(moment(a.completed_date).format(constant.DATE_FORMAT)) <
      new Date(moment(b.completed_date).format(constant.DATE_FORMAT))
    )
      return 1;
    else if (
      new Date(moment(a.completed_date).format(constant.DATE_FORMAT)) >
      new Date(moment(b.completed_date).format(constant.DATE_FORMAT))
    )
      return -1;
    else return 0;
  }
}

export const { useGetEvalRunDetailsQuery, useGetDataQuery } = evalRunApiSlice;
