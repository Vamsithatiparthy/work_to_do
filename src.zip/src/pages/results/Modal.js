import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { useToast } from "@abyss/web/hooks/useToast";
import { Badge } from "@abyss/web/ui/Badge";
import { RadioGroup } from "@abyss/web/ui/RadioGroup";
import {
  Button,
  Dialog,
  FormControl,
  Label,
  Text,
  TextArea,
} from "@uitk/react";
import PropTypes from "prop-types";

import { reportStatus, toastConstants } from "../../utils/constants";

function Modal({
  openModal,
  currentUser,
  closeModal,
  modalType,
  onChangeHandler,
  notes,
  updateQcStatus,
  setThreshold,
  currentCcDataVersion,
  evalRunData,
}) {
  const displayBenchmarkOption =
    modalType === reportStatus.APPROVED && evalRunData.eval_runs.cc.length > 0;
  const { clientId: client, env, level, version } = useParams();
  const { toast } = useToast();
  const handleModalClose = async () => {
    closeModal();
    try {
      await setThreshold({
        client: client,
        env: env,
        level: level,
        version: version,
        dataVersion: currentCcDataVersion,
        applyBenchmarkMode: benchmarkOption,
        setBy: currentUser,
      }).unwrap();
      await updateQcStatus({
        reviewed_by: currentUser,
        reviewed_on: new Date(),
        review_outcome: modalType,
        review_comments: notes,
      });
    } catch (error) {
      toast.show({
        title: toastConstants.ERROR_UPDATING_RECORDS,
        variant: toastConstants.ERROR,
      });
    }
  };
  const [benchmarkOption, setBenchmarkOption] = useState("0");

  return (
    <>
      {openModal && (
        <>
          <Dialog
            className="dialogBox"
            open={openModal}
            titleAs="h1"
            closeButtonText="X"
            onClose={closeModal}
          >
            <h1>Confirmation</h1>
            {displayBenchmarkOption && (
              <div>
                <Badge rounded outline width="200px" variant="info">
                  {evalRunData.review_details.post_review_action
                    ? "Post review action"
                    : "No post review action"}
                </Badge>
              </div>
            )}
            <Dialog.Body>
              <Text>
                Do you want to proceed with the
                {modalType === reportStatus.APPROVED
                  ? " approval "
                  : " rejection "}
                of your report by:
              </Text>
              {displayBenchmarkOption && (
                <RadioGroup
                  label=""
                  onChange={(e) => setBenchmarkOption(e.target.value)}
                  value={benchmarkOption}
                >
                  <RadioGroup.Radio
                    label="Proceeding without applying benchmarks"
                    value="0"
                  />
                  <RadioGroup.Radio
                    label="Applying benchmarks only to failed checks"
                    value="1"
                  />
                  <RadioGroup.Radio
                    label="Applying benchmarks to all checks"
                    value="2"
                  />
                </RadioGroup>
              )}
              <FormControl className="notes" required>
                <Label>Notes</Label>
                <TextArea
                  required
                  className="notes-textarea"
                  onChange={onChangeHandler}
                />
              </FormControl>
            </Dialog.Body>
            <Dialog.Actions>
              <Button disabled={notes === ""} onPress={handleModalClose}>
                Proceed
              </Button>
            </Dialog.Actions>
          </Dialog>
        </>
      )}
    </>
  );
}

Modal.propTypes = {
  openModal: PropTypes.bool,
  currentUser: PropTypes.string,
  closeModal: PropTypes.func,
  modalType: PropTypes.string,
  onChangeHandler: PropTypes.func,
  notes: PropTypes.string,
  updateQcStatus: PropTypes.func,
  setThreshold: PropTypes.func,
  currentCcDataVersion: PropTypes.string,
  evalRunData: PropTypes.object,
};

export default Modal;
