import { apiSlice } from "../../app/apiSlice";
// import { camelCase } from "../../utils/common";
import { constant } from "../../utils/constants";

export const analyseChartApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    /* Below code needs to be uncommented if we require root filters api */

    // getRootFilters: builder.query({
    //   query: (id) => `${constant.EVAL_RUN}/${id}/${constant.ROOT_FILTER}`,
    //   transformResponse: (response) => {
    //     const filterName = response?.name;
    //     let filterLabel = "";
    //     let filterOptions = [];
    //     let stateName = "ruleType";
    //     // if root filter is rule type then set the respective label and values
    //     if (filterName === "rule") {
    //       filterLabel = "Rule Type";
    //       filterOptions = response?.data?.map((item) => ({
    //         ...item,
    //         label: item.value,
    //       }));
    //     } else {
    //       // if root filter is partition column then set the respective label and values
    //       filterLabel = filterName.replace("partition_granularity.", "");
    //       filterOptions = response?.data?.map((item) => ({
    //         ...item,
    //         label: item.value,
    //       }));
    //       stateName = camelCase(filterLabel);
    //     }
    //     return {
    //       label: filterLabel,
    //       options: filterOptions,
    //       stateName: stateName,
    //     };
    //   },
    // }),
    getEvalResults: builder.mutation({
      query({ id, data }) {
        return {
          url: `/${constant.EVAL_RUN}/${id}/${constant.EVAL_RESULT}/search`,
          method: "POST",
          body: data,
        };
      },
    }),
  }),
});

export const { useGetEvalResultsMutation } = analyseChartApiSlice;
