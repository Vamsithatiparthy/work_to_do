import React from "react";
import Plot from "react-plotly.js";
import { Badge } from "@abyss/web/ui/Badge";
// import { IconSymbol } from "@abyss/web/ui/IconSymbol";
import { Table, Tooltip } from "@uitk/react";
import { TabbedPanel } from "@uitk/react";
import { ChartLine, ChartRow } from "@uitk/react-icons";
import PropTypes from "prop-types";

import pinIcon from "../../assets/pinIcon.svg";
import { filterDataPoints, titleCase } from "../../utils/common";
import { chartTypes, constant } from "../../utils/constants";

function Chart({ chartData, setLoading }) {
  setLoading(false);

  const {
    rule_name,
    rule_display_name,
    description,
    model_name,
    column_name,
    rule,
    severity,
    checkQualityDimension,
    checkTags: check_tags,
    segment_column_name,
    segment_column_value,
    partition_granularity,
    flagged_status,
    confidence_score,
    is_core,
    is_success,
    chart_value,
    chart_layout,
    table_content,
    table_content_cols,
  } = chartData;

  const { filteredChartValue, filteredTableContent } = filterDataPoints(
    chart_value,
    table_content
  );

  const showPartitionGranularity =
    (partition_granularity && Object.keys(partition_granularity).length > 0) ||
    segment_column_name?.length > 0 ||
    segment_column_value?.length > 0;

  const timeseries_chart_types = [
    "mad_qreg_timeseriesanalysis",
    "timeseriesanalysis",
    "dist_comp_analysis",
  ];

  const displayFlaggedStatus = !timeseries_chart_types.includes(rule);

  if (rule === chartTypes.THRESHOLD_ANALYSIS) {
    // pass
  }
  // add anomaly data points to chart data for normal charts
  else if (!timeseries_chart_types.includes(rule)) {
    const axisSuffix = ["", "2", "3"];
    // get only datapoints which have anomaly
    for (let i = 0; i < 3; i++) {
      const x_axis_data = [];
      const y_axis_data = [];
      const text_data = [];
      filteredChartValue[i].x.forEach((item, index) => {
        if (filteredTableContent[index].failure_class) {
          x_axis_data.push(item);
          y_axis_data.push(filteredChartValue[i].y[index]);
          text_data.push(filteredChartValue[i].text[index]);
        }
      });
      // add anomaly data points to chart data
      filteredChartValue[i].legendgroup = `group${i}`;
      filteredChartValue.push({
        ...filteredChartValue[i],
        name: `Anomaly Data Points`,
        mode: "markers",
        x: x_axis_data,
        xaxis: `x${axisSuffix[i]}`,
        y: y_axis_data,
        yaxis: `y${axisSuffix[i]}`,
        text: [],
        marker: {
          color: "black",
          symbol: "circle-open",
          size: 12,
        },
        showlegend: false,
        legendgroup: `group${i}`,
      });
    }
    // adding empty chart data for adding legend for anomaly data points
    filteredChartValue.push({
      x: [null],
      y: [null],
      mode: "markers",
      name: "Anomaly Data Points",
      marker: {
        color: "black",
        symbol: "circle-open",
        size: 12,
      },
      showlegend: true,
    });
  }
  // add anomaly data points to chart data for timeseries charts
  else {
    const anomalyXData = filteredTableContent.reduce((acc, curr) => {
      if (curr.failure_class) {
        acc.push(curr.timeseries_column_value);
      }
      return acc;
    }, []);
    const colors = ["#1E82CB", "#E4780C", "rgb(45 160 45)", "red", "black"];
    for (let i = 0; i < filteredChartValue.length; i++) {
      filteredChartValue[i].marker = { color: colors[i % colors.length] };
    }

    const anomalyYData = [];
    filteredChartValue[2].x.map((x, index) => {
      if (anomalyXData.includes(x)) {
        anomalyYData.push(filteredChartValue[2].y[index]);
      }
    });
    filteredChartValue[2].legendgroup = "current build";
    filteredChartValue.push({
      ...filteredChartValue[2],
      name: "Anomaly Data Points",
      mode: "markers",
      x: anomalyXData,
      y: anomalyYData,
      text: [],
      marker: {
        color: "black",
        symbol: "circle-open",
        size: 12,
      },
      legendgroup: "current build",
    });
    [filteredChartValue[2], filteredChartValue[3]] = [
      filteredChartValue[3],
      filteredChartValue[2],
    ];
  }

  filteredTableContent.sort((a, b) => {
    if (a?.build < b?.build) {
      return -1;
    }
    if (a?.build > b?.build) {
      return 1;
    }
    return 0;
  });

  table_content_cols.map((col) => {
    col.label = titleCase(col.label);
  });
  const tableConfig = {
    columns: table_content_cols,
    sticky: {
      maxHeight: "450px",
    },
  };
  const panels = [
    rule !== chartTypes.THRESHOLD_ANALYSIS && {
      header: (
        <>
          <ChartLine />
        </>
      ),
      content:
        filteredChartValue[0]?.x.length > 0 ? (
          <>
            <div data-testid={`${rule}_chart`}>
              <Plot
                className="w-full"
                useResizeHandler
                data={filteredChartValue}
                layout={chart_layout}
              />
            </div>
          </>
        ) : (
          <div className="flex justify-center h-[70px]">
            <p className="font-semibold text-lg">{constant.NO_DATA}</p>
          </div>
        ),
    },
    {
      header: (
        <>
          <ChartRow />
        </>
      ),
      content:
        filteredTableContent.length > 0 ? (
          <>
            <Table
              data-testid={`${rule}_table`}
              className="charts-table"
              data={filteredTableContent}
              config={tableConfig}
            />
          </>
        ) : (
          <div className="flex justify-center h-[70px]">
            <p className="font-semibold text-lg">{constant.NO_DATA}</p>
          </div>
        ),
    },
  ].filter(Boolean);
  const constructPartitionGranularityHTML = () => {
    let partitionGranularityHTML = "";
    for (let [key, value] of Object.entries(partition_granularity)) {
      if (key === "client_id" && value === undefined) {
        value = partition_granularity["groupid"];
      }
      if (value !== undefined)
        partitionGranularityHTML += `${key}: ${value} | `;
    }
    if (segment_column_name)
      partitionGranularityHTML += `segment_column_name: ${segment_column_name} | `;
    if (segment_column_value)
      partitionGranularityHTML += `segment_column_value: ${segment_column_value}`;
    return partitionGranularityHTML;
  };
  const getMoreDetails = () => {
    const { interval_time } = chartData;
    return (
      <>
        {description}
        <p>Comparator Count: {confidence_score}</p>
        {interval_time && <p>Interval Format: {interval_time}</p>}
        <p>Severity: {severity}</p>
        <p>{confidence_score < 3 ? constant.AI_CHART_INFO : ""}</p>
      </>
    );
  };

  const getBadge = (content, className) => {
    return (
      <div className="pr-4">
        <Badge
          rounded
          variant="warning"
          outline={false}
          ariaText="information"
          className={className}
        >
          {content}
        </Badge>
      </div>
    );
  };
  return (
    <div
      className="border-solid border-b-8 border-[#E0E0E0] mb-16"
      data-testid="render-chart"
    >
      <div className="flex pb-2">
        <p className="flex flex-row">
          <span className="font-bold">Rule Name:&nbsp;</span>
          <span data-testid={`${rule}-${rule_name}`} className="flex gap-[5px]">
            {rule_display_name || rule_name}
            {is_core && (
              <Tooltip content={constant.CORE_RULES}>
                <img src={pinIcon} alt="core" height="20px" width="20px" />
              </Tooltip>
            )}
          </span>
        </p>
      </div>
      <div className="flex pb-2">
        <p>
          <span className="font-bold">Entity Details:&nbsp;</span>
          <span data-testid={`${rule}-${model_name}-${column_name}`}>
            model_name: {model_name} | column_name: {column_name}
          </span>
        </p>
      </div>
      {showPartitionGranularity && (
        <div className="flex pb-2">
          <p>
            <span className="font-bold"> Partition Granularity:&nbsp;</span>
            <span
              data-testid={`${rule}-${
                partition_granularity?.client_ds_id || "unknown"
              }`}
            >
              {constructPartitionGranularityHTML()}
            </span>
          </p>
        </div>
      )}
      {check_tags && Object.keys(check_tags).length > 0 && (
        <div className="flex pb-2">
          <p>
            <span className="font-bold"> Tags:&nbsp;</span>
            <span>
              {Object.entries(check_tags)
                .map(([key, value]) => `${key}: ${value}`)
                .join(" | ")}
            </span>
          </p>
        </div>
      )}
      <div className="flex pt-2">
        <Tooltip
          content={getMoreDetails()}
          className="underline text-[#002677]"
        >
          More Details
        </Tooltip>
      </div>
      <div className="pt-5 flex">
        {getBadge(
          displayFlaggedStatus
            ? `${is_success ? "Success" : "Failure"} - ${flagged_status
                ?.replaceAll("FlagStatus.", "")
                .replaceAll("_", " ")}`
            : `${is_success ? "Success" : "Failure"}`,
          `${
            is_success
              ? "!bg-[#99C699] text-black !max-w-[260px]"
              : "!bg-[#FBE299] text-black !max-w-[260px]"
          }`
        )}
        {checkQualityDimension &&
          checkQualityDimension.map((item) => {
            const qd = titleCase(item);
            return getBadge(qd, "!bg-[#D9F6FA] text-black ");
          })}
      </div>
      <TabbedPanel className="pb-0" panels={panels} titlesAs="h2" />
    </div>
  );
}

Chart.propTypes = {
  chartData: PropTypes.object,
  setLoading: PropTypes.func,
};

export default Chart;
