import React from "react";
import { act, fireEvent, screen, waitFor } from "@testing-library/react";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";

import Dashboard from "./Dashboard";

let component = null;
beforeEach(async () => {
  await act(async () => {
    component = renderWithProviders(
      <Toolkit>
        <Dashboard />
      </Toolkit>
    );
  });
});

afterEach(() => {
  component.unmount();
});

describe("Renders Dashboard Component correctly", () => {
  test("Renders Dashboard Component correctly", async () => {
    await waitFor(() => {
      expect(screen.getByTestId(/dashboard-page/i)).toBeInTheDocument();
    });
  });

  test("Dashboard Table renders correctly", async () => {
    await waitFor(() => {
      const searchContainer = screen.getByRole("dashboard-table");
      const completed_date = "07/26/2023";
      expect(
        screen.getAllByText(/H823568/i, { container: searchContainer })[0]
      ).toBeInTheDocument(),
        expect(
          screen.getAllByText(/202306/i, {
            container: searchContainer,
          })[0]
        ).toBeInTheDocument(),
        expect(
          screen.getAllByText(completed_date, {
            container: searchContainer,
          })[0]
        ).toBeInTheDocument();
    });
  });
});

describe("Filters in Dashboard Component works correctly", () => {
  test("Clientid filter in Dashboard Component works correctly", async () => {
    const clientidFilter = await screen.findByTestId("clientid-filter");
    fireEvent.change(clientidFilter, {
      target: {
        value: "H623568",
      },
    });
    const applyBtn = await screen.findByTestId("dashboard-filter-apply-btn");
    await waitFor(() => {
      fireEvent.click(applyBtn);
    });

    const tableRow = await screen.findAllByTestId("table-row");
    await waitFor(() => {
      expect(tableRow.length).toBe(1);
    });
  });

  test("Build Value filter in Dashboard Component works correctly", async () => {
    const versionFilter = await screen.findByTestId("version-filter");
    fireEvent.change(versionFilter, {
      target: {
        value: "202306",
      },
    });
    const applyBtn = await screen.findByTestId("dashboard-filter-apply-btn");
    await waitFor(() => {
      fireEvent.click(applyBtn);
    });
    const tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(7);
  });

  test("Level filter in Dashboard Component works correctly", async () => {
    const levelFilter = await screen.findByTestId("level-filter");
    fireEvent.change(levelFilter, {
      target: {
        value: "DVP_CC",
      },
    });
    const applyBtn = await screen.findByTestId("dashboard-filter-apply-btn");
    await waitFor(() => {
      fireEvent.click(applyBtn);
    });
    const tableRow = await screen.findAllByTestId("table-row");
    await waitFor(() => {
      expect(tableRow.length).toBe(10);
    });
  });

  test("Report status filter in Dashboard Component works correctly", async () => {
    const readytoreviewChekbox = await screen.findByTestId(
      "readytoreview-filter"
    );
    const disapproveChekbox = await screen.findByTestId("disapproved-filter");
    fireEvent.click(readytoreviewChekbox);

    fireEvent.click(disapproveChekbox);

    const applyBtn = await screen.findByTestId("dashboard-filter-apply-btn");

    await waitFor(() => {
      fireEvent.click(applyBtn);
    });

    const disapproveTableRow = await screen.findAllByTestId("table-row");
    expect(disapproveTableRow.length).toBe(1);
    // check below test why its failing later
    // fireEvent.click(disapproveChekbox);
    // const approveChekbox = await screen.findByTestId("approved-filter");
    // fireEvent.click(approveChekbox);
    // await waitFor(() => {
    //   fireEvent.click(applyBtn);
    // });
    // const approveTableRow = await screen.findAllByTestId("table-row");
    // expect(approveTableRow.length).toBe(1);
  });

  test("Date filter in Dashboard Component works correctly", async () => {
    const fromDateFilter = await screen.findByTestId("fromdate-filter");
    fireEvent.change(fromDateFilter, {
      target: {
        value: "2023-02-23",
      },
    });

    const toDateFilter = await screen.findByTestId("todate-filter");
    await waitFor(() => {
      fireEvent.change(toDateFilter, {
        target: {
          value: "2023-07-24",
        },
      });
    });

    const applyBtn = await screen.findByTestId("dashboard-filter-apply-btn");

    await waitFor(() => {
      fireEvent.click(applyBtn);
    });
    let tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(2);
  });

  test("Reset filter in Dashboard Component works correctly", async () => {
    const levelFilter = await screen.findByTestId("level-filter");
    fireEvent.change(levelFilter, {
      target: {
        value: "DVP_CC",
      },
    });
    const applyBtn = await screen.findByTestId("dashboard-filter-apply-btn");
    fireEvent.click(applyBtn);
    const tableRow = await screen.findAllByTestId("table-row");
    await waitFor(() => {
      expect(tableRow.length).toBe(10);
    });

    const resetBtn = await screen.findByTestId("dashboard-filter-reset-btn");
    fireEvent.click(resetBtn);
    const afterResetTableRow = await screen.findAllByTestId("table-row");
    await waitFor(() => {
      expect(afterResetTableRow.length).toBe(10);
    });
  });
});
