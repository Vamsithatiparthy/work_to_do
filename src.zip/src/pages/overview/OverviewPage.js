import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { LoadingIndicator, Pagination, Table, Tooltip } from "@uitk/react";
import { CheckmarkFilled } from "@uitk/react-icons";
import moment from "moment";

import cancel from "../../assets/cancel.svg";
import eye from "../../assets/eye.svg";
import { formatDateTime } from "../../utils/common";
import { constant, reportStatus } from "../../utils/constants";
import DashboardFilter from "../dashboard/DashboardFilter";
import { useGetEvalRunDetailsQuery } from "../dashboard/evalRunApiSlice";
import {
  selectFilteredEvalResult,
  setEvalResults,
  setUnstructuredEvalResults,
} from "../dashboard/evalRunSlice";
/*
This function is used to transform the data to the required format for the table.
It groups the data based on clientid, version and env for individual rows.
Each row is further grouped based on the date so that the levels with same date are grouped together.
*/
const updateFilteredData = (data) => {
  const groupedData = {};
  data.forEach((element) => {
    const key = `${element.clientid}-${element.version}-${element.env}`;

    if (!groupedData[key]) {
      groupedData[key] = {
        clientid: element.clientid,
        env: element.env,
        version: element.version,
        level: [],
      };
    }

    groupedData[key].level.push({
      completed_date: moment(new Date(element.completed_date)).format(
        constant.DATE_FORMAT
      ),
      level: element.level,
      review_details: element.review_details,
      id: element.id,
    });
  });

  const updatedFilterData = Object.values(groupedData).map((group) => {
    const uniqueLevelData = group.level.reduce((acc, level) => {
      const key = level.completed_date;

      if (!acc[key]) {
        acc[key] = {
          completed_date: key,
          level: [],
        };
      }

      acc[key].level.push(level);
      return acc;
    }, {});

    return {
      ...group,
      level: Object.values(uniqueLevelData),
    };
  });
  return updatedFilterData;
};

function Overview() {
  const history = useHistory();
  const dispatch = useDispatch();

  const { data, isLoading, isError } = useGetEvalRunDetailsQuery("eval_run");
  const evalRunDetails = data?.structuredEvalResults;
  const [page, setPage] = useState(1);

  const getfilteredEvalResults = useSelector(selectFilteredEvalResult);
  const filteredEvalResults = updateFilteredData(getfilteredEvalResults);

  const { unStructuredEvalResults } = useSelector((state) => state.evalResults);
  useEffect(() => {
    if (!isLoading) {
      // check weather these two dispatch functions are needed in future
      dispatch(setEvalResults([...evalRunDetails]));
      dispatch(setUnstructuredEvalResults(data?.unStructuredEvalResults));
    }
  }, [isLoading]);

  useEffect(() => {
    setPage(1);
  }, [getfilteredEvalResults]);

  const goToResultsPage = async (e, dvp_run_details, index, levelIndex, source) => {
    const evalRunClicked = unStructuredEvalResults.find(
      (evalRun) =>
        evalRun.clientid === dvp_run_details.clientid &&
        evalRun.env === dvp_run_details.env &&
        evalRun.level ===
          dvp_run_details.level[index].level[levelIndex].level &&
        evalRun.version === dvp_run_details.version
    );
    localStorage.setItem("evalRunClicked", JSON.stringify(evalRunClicked));
    const url = `/dvpRuns/clientId/${evalRunClicked.clientid}/env/${evalRunClicked.env}/level/${evalRunClicked.level}/version/${evalRunClicked.version}?source=${source}`;
    if (e.metaKey || e.ctrlKey) {
      window.open(url, "_blank");
    } else {
      history.push(url);
    }
  };
  

  const renderDateLevelColumn = (data) => {
    const reportStatusIcon = (status) => {
      return status === reportStatus.APPROVED ? (
        <CheckmarkFilled
          className="report-icon"
          customSize="17px"
          fill="rgb(98, 125, 50)"
        />
      ) : status === reportStatus.REJECTED ? (
        <img className="report-icon" src={cancel} />
      ) : (
        <img className="report-icon" src={eye} />
      );
    };

    const toolTipData = (data) => {
      const review_outcome = data?.review_details?.review_outcome;
      const review_by = data?.review_details?.reviewed_by;
      const review_on = data?.review_details?.reviewed_on;
      const review_comments = data?.review_details?.review_comments;
      const status =
        review_outcome === reportStatus.APPROVED
          ? "Approved"
          : review_outcome === reportStatus.REJECTED
          ? "Rejected"
          : null;
      return (
        <>
          More Info <br />
          {(review_outcome === reportStatus.APPROVED ||
            review_outcome === reportStatus.REJECTED) && (
            <div style={{ zIndex: "10" }}>
              <li>
                {status} by: {review_by}
              </li>
              <li>
                {status} on: {formatDateTime(review_on)}
              </li>
              <li>Notes: {review_comments}</li>
            </div>
          )}
          {data["review_details"]["review_outcome"] === null && (
            <div>Pending review</div>
          )}
        </>
      );
    };

    return data.level.map((date, index) => {
      const formattedDate = date.completed_date;
      return (
        <>
          <div className="dateLevel">
            <div
              key={index}
              id={`date-${data.clientid}-${data.version}-${index}`}
              className="row-item"
            >
              {formattedDate}
            </div>
            <div style={{ display: "flex", flexWrap: "wrap" }}>
              {date.level.map((level, levelIndex) => {
                return (
                  <div key={levelIndex} className="level-container">
                    <Tooltip content={toolTipData(level)} placement="top">
                      <div
                        className="flex align-center level-item"
                        key={level.level}
                        onClick={(e) => {
                          goToResultsPage(e, data, index, levelIndex, "overview");
                        }}
                      >
                        <div className="reportStatus-icon">
                          {reportStatusIcon(
                            level.review_details.review_outcome
                          )}
                        </div>
                        <div className="level">{level.level}</div>
                      </div>
                    </Tooltip>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      );
    });
  };

  /**
   * UI Toolkit Table component configurations.
   */
  const config = {
    columns: [
      {
        label: "Client ID",
        key: "clientid",
        sortColumn: true,
      },
      {
        label: "Environment",
        key: "env",
        sortColumn: true,
      },
      {
        label: "Build Value",
        key: "version",
        sortColumn: true,
      },
      {
        label: (
          <p className="date-level">
            <span>Date</span>
            <span>Level</span>
          </p>
        ),
        key: "dateLevel",
        onRenderCell: renderDateLevelColumn,
        sortColumn: false,
      },
    ],
    sort: true,
  };

  /**
   * UI Toolkit Pagination component configurations.
   */
  const paginationConfig = {
    pageSize: 10,
    totalItemsCount: filteredEvalResults?.length,
  };

  const entriesPerPageConfig = {
    pageSizeOptions: [
      {
        label: "10",
        value: 10,
      },
      {
        label: "50",
        value: 50,
      },
      {
        label: "100",
        value: 100,
      },
    ],
    initialValue: 10,
  };

  const onPageChange = (page) => {
    setPage(page);
  };

  return (
    <div style={{ minHeight: "calc(100% - 48px)" }}>
      {isLoading && (
        <LoadingIndicator
          size={"l"}
          loading={isLoading}
          centerSpinner={true}
          className="loader"
        />
      )}
      {isError && <p className="loader">{constant.SERVER_ERROR}</p>}
      {!isLoading && (
        <div className="table_section" data-testid={"dashboard-page"}>
          <div className="filter">
            <DashboardFilter />
          </div>
          {constant.NUMBER_OF_RECORDS} : {filteredEvalResults?.length}
          <br />
          <br />
          <Pagination
            id="pagination-entries"
            config={paginationConfig}
            entriesPerPageConfig={entriesPerPageConfig}
            onPageChange={onPageChange}
            page={page}
            className={`${
              filteredEvalResults.length === 0 ? "no-pagination" : "pagination"
            }`}
          >
            {({ pageSize }) => {
              return (
                <>
                  <Table
                    id="sticky-header-table"
                    className="dashboard-table"
                    data={filteredEvalResults}
                    page={page}
                    pageSize={pageSize}
                    config={config}
                    role="dashboard-table"
                  />

                  {filteredEvalResults.length === 0 && (
                    <div className="no-records-message-dashboard-table">
                      <p>No records to show.</p>
                    </div>
                  )}
                </>
              );
            }}
          </Pagination>
          <div className="legend">
            <span className="flex align-center">
              <img src={eye} className="legend-icon" />
              <span>{constant.READY_FOR_REVIEW}</span>
              <img src={cancel} className="legend-icon" />
              <span>{constant.REJECTED}</span>
              <CheckmarkFilled className="legend-icon-checkbox" />
              <span>{constant.APPROVED}</span>
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

Overview.propTypes = {};

export default Overview;
