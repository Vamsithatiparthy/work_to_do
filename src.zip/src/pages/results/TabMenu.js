import React from "react";
import { Tooltip } from "@uitk/react";
import { MenuHidden } from "@uitk/react-icons";
import PropTypes from "prop-types";

import { navigationTabs } from "../../utils/constants";
function TabMenu({ navItems, activeTab, handleTabChange, handleDataVersion }) {
  const toolTipMenu = (data) => {
    const renderOptions = (item, options) => {
      return options.map((option, index) => (
        <li key={index} onClick={() => handleDataVersion(item.title, option)}>
          {option}
        </li>
      ));
    };

    return (
      <>
        Versions
        <br />
        {navItems.length > 0 &&
          navItems.map((item) => {
            if (
              (item.title === navigationTabs.CONTENT_CHECK_RESULTS &&
                data.title === navigationTabs.CONTENT_CHECK_RESULTS) ||
              (item.title === navigationTabs.AI_CHECK_RESULTS &&
                data.title === navigationTabs.AI_CHECK_RESULTS)
            ) {
              return renderOptions(item, item.options);
            }
          })}
      </>
    );
  };
  const menu = (item) => {
    return (
      <Tooltip title="Versions" content={toolTipMenu(item)} placement="bottom">
        <MenuHidden />
      </Tooltip>
    );
  };

  return navItems.length > 0 ? (
    <>
      <div className="tabMenu">
        {navItems.map(
          (item, index) =>
            item.title.length > 0 && (
              <div className="nav-item-container" key={index}>
                <button
                  className="nav-item"
                  onClick={() => handleTabChange(item.title)}
                  style={{
                    fontWeight: activeTab === item.title ? "bold" : "normal",
                    borderBottom:
                      activeTab === item.title
                        ? "2px solid blue"
                        : "2px solid grey",
                  }}
                >
                  {item.title === navigationTabs.CONTENT_CHECK_RESULTS
                    ? navigationTabs.CONTENT_CHECK_RESULTS
                    : item.title === navigationTabs.AI_CHECK_RESULTS ? navigationTabs.AI_CHECK_RESULTS : navigationTabs.SUMMARY}
                  {item.options.length > 1 && menu(item)}
                </button>
              </div>
            )
        )}
      </div>
    </>
  ) : (
    <div> No Data for nav items</div>
  );
}

TabMenu.propTypes = {
  navItems: PropTypes.array,
  activeTab: PropTypes.string,
  updateActiveTab: PropTypes.func,
  handleTabChange: PropTypes.func,
  handleDataVersion: PropTypes.func,
};

export default TabMenu;
