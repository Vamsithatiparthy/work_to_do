import React from "react";
import { act, fireEvent, waitFor } from "@testing-library/react";
import { Toolkit } from "@uitk/react";
import { createMemoryHistory } from "history";

import { renderWithProviders } from "../../test/test-utils";

import RouterPrompt from "./RouterPrompt";

describe("RouterPrompt", () => {
  it("should render correctly when 'when' is true", () => {
    const history = createMemoryHistory();
    const { queryByTestId, unmount } = renderWithProviders(
      <Toolkit>
        <RouterPrompt
          when={true}
          title="Leave Page?"
          content="You have unsaved changes. Are you sure you want to leave this page?"
          variant="warning"
          history={history}
        />
      </Toolkit>
    );
    expect(queryByTestId("router-prompt")).toBeNull();
    act(() => {
      history.push("/new-route");
    });

    expect(queryByTestId("router-prompt")).toBeInTheDocument();
    unmount();
  });

  test("Clicking Leave page button navigates to new path", async () => {
    const history = createMemoryHistory();
    const { getByTestId, getByText, queryByTestId, unmount } =
      renderWithProviders(
        <Toolkit>
          <RouterPrompt
            when={true}
            title="Leave Page?"
            content="You have unsaved changes. Are you sure you want to leave this page?"
            variant="warning"
            history={history}
          />
        </Toolkit>
      );
    expect(queryByTestId("router-prompt")).toBeNull();
    act(() => {
      history.push("/new-route");
    });
    const dialog = await waitFor(() => getByTestId("router-prompt"));
    expect(dialog).toBeVisible();

    const leavePageButton = getByText("Leave page");
    waitFor(() => {
      fireEvent.click(leavePageButton);
    });

    waitFor(() => {
      expect(history.location.pathname).toBe("/new-route");
    });
    unmount();
  });

  test("Clicking Stay on page button does not navigates to new path", async () => {
    const history = createMemoryHistory();
    const { getByTestId, getByText, queryByTestId, unmount } =
      renderWithProviders(
        <Toolkit>
          <RouterPrompt
            when={true}
            title="Leave Page?"
            content="You have unsaved changes. Are you sure you want to leave this page?"
            variant="warning"
            history={history}
          />
        </Toolkit>
      );
    expect(queryByTestId("router-prompt")).toBeNull();
    act(() => {
      history.push("/new-route");
    });
    const dialog = await waitFor(() => getByTestId("router-prompt"));
    expect(dialog).toBeVisible();

    const stayOnPageButton = getByText("Stay on page");
    fireEvent.click(stayOnPageButton);

    expect(history.location.pathname).toBe("/");
    unmount();
  });
  test("displays confirmation message when tab is closed", () => {
    const history = createMemoryHistory();
    const { unmount } = renderWithProviders(
      <Toolkit>
        <RouterPrompt
          when={true}
          title="Leave Page?"
          content="You have unsaved changes. Are you sure you want to leave this page?"
          variant="warning"
          history={history}
        />
      </Toolkit>
    );
    window.dispatchEvent(new Event("beforeunload"));

    unmount();
  });
});
