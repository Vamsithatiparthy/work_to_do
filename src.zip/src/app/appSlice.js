import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  loader: {
    isLoading: false,
    loadingText: "",
  },
};

const appSlice = createSlice({
  name: "app",
  initialState,
  reducers: {
    toggleLoading(state, action) {
      state.loader.isLoading = action.payload.isLoading;
      state.loader.loadingText = action.payload.loadingText;
    },
  },
});

export const { toggleLoading } = appSlice.actions;
export default appSlice.reducer;
