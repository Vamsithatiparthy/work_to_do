import { apiSlice } from "../../app/apiSlice";

export const HeaderApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    logout: builder.query({
      query: () => "logout",
    }),
    getUserDetails: builder.query({
      query: () => "user",
    }),
  }),
});

export const { useLazyLogoutQuery, useGetUserDetailsQuery } = HeaderApiSlice;
