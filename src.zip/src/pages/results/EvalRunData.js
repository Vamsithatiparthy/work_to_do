import React, { useEffect } from "react";
import { useHistory } from "react-router-dom";
import { useParams } from "react-router-dom/cjs/react-router-dom.min";
import { LoadingIndicator } from "@uitk/react";
import PropTypes from "prop-types";

import { useGetDataQuery } from "../dashboard/evalRunApiSlice";
function EvalRunData({ handleEvalData }) {
  const history = useHistory();
  const { clientId, env, level, version } = useParams();
  const {
    data: evalRunData,
    isLoading,
    error,
  } = useGetDataQuery({ clientId, env, level, version });

  useEffect(() => {
    if (evalRunData) {
      handleEvalData(evalRunData);
    }
  }, [evalRunData]);

  useEffect(() => {
    if (!isLoading && error) {
      history.push("/dashboard");
    }
  }, [isLoading, error]);

  return (
    <>
      {isLoading && (
        <LoadingIndicator
          size={"l"}
          loading={isLoading}
          centerSpinner={true}
          className="loader"
        />
      )}
    </>
  );
}

EvalRunData.propTypes = {
  handleEvalData: PropTypes.func,
};

export default EvalRunData;
