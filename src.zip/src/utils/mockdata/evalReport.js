const mockData = {
  id: "application_1657584717681_0004_2022071f20139409",
  clientid: "H704847",
  version: "202006",
  data_version: "1",
  level: "cdr_be",
  env: "dev",
  sequence_number: 202006,
  report_status: "readytoreview",
  is_completed: true,
  is_successful: false,
  completed_date: "08/10/2022",
  source_db: "h704847_data_quality_dev_srd_cdr_be_202006",
  previous_source_db: "h704847_data_quality_dev_srd_cdr_be_202005",
};

export default mockData;
