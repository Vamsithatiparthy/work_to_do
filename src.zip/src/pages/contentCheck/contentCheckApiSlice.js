import { apiSlice } from "../../app/apiSlice";
import { constant } from "../../utils/constants";

export const contentCheckApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getContentCheckRecords: builder.query({
      query: ({ clientId, env, level, version, dataVersion }) =>
        `${constant.CONTENT_CHECK_API}/clientId/${clientId}/env/${env}/level/${level}/version/${version}/dataVersion/${dataVersion}`,
      transformResponse: async (response) => {
        return restructureContentChecks(response);
      },
    }),
    setThreshold: builder.mutation({
      query({
        client,
        env,
        level,
        version,
        dataVersion,
        applyBenchmarkMode,
        setBy,
      }) {
        const thresholdBody = {
          client,
          env,
          level,
          version,
          dataVersion,
          applyBenchmarkMode,
          setBy,
        };
        return {
          url: `setThreshold`,
          method: "POST",
          body: thresholdBody,
          validateStatus: (response) => {
            return response.status >= 200 && response.status < 300;
          },
        };
      },
      transformErrorResponse: (response) => {
        return {
          status: response.status,
          data: response.data,
          message: response?.data?.message || "An error occurred",
        };
      },
    }),
  }),
});

const restructureContentChecks = (data) => {
  const contentCheckHeader = {
    clientid: data.clientid,
    created_on: data.created_on,
  };
  const dataset_check_summary = data.dataset_check_summary;
  // group the records by view name which will be used to fed both table and nested table
  const restructuredContentChecks = dataset_check_summary.reduce(
    (accumulator, currentValue) => {
      const view_name = currentValue.view_name;
      if (!accumulator["tableData"][view_name]) {
        accumulator["tableData"][view_name] = {
          id: view_name,
          view_name,
          bad_rows_count: currentValue.bad_rows > 0 ? 1 : 0,
          check_count: 1,
          accept: isCheckAccepted(data.dataset_summary, view_name),
        };
        accumulator["nestedTableData"][view_name] = [currentValue];
      } else {
        const bad_rows_count =
          accumulator["tableData"][view_name].bad_rows_count;
        const check_count = accumulator["tableData"][view_name].check_count + 1;
        accumulator["tableData"][view_name] = {
          ...accumulator["tableData"][view_name],
          bad_rows_count:
            currentValue.bad_rows > 0 ? bad_rows_count + 1 : bad_rows_count,
          check_count,
        };
        accumulator["nestedTableData"][view_name].push(currentValue);
      }
      return accumulator;
    },
    { tableData: {}, nestedTableData: {} }
  );

  // by default sort check count with bad rows column by descending order.
  // by default sort bad row percentage of every nested row by decending order.
  // create records for nested table
  return {
    tableData: sortTableData(restructuredContentChecks.tableData),
    nestedTableData: sortNestedTableData(
      restructuredContentChecks.nestedTableData
    ),
    contentCheckHeader,
    dataset_summary: data.dataset_summary,
    dataset_check_summary: data.dataset_check_summary,
  };
};

const sortTableData = (data) => {
  return Object.values(data).sort((a, b) =>
    a.bad_rows_count < b.bad_rows_count
      ? 1
      : a.bad_rows_count > b.bad_rows_count
      ? -1
      : 0
  );
};

const sortNestedTableData = (data) => {
  const sortedNestedTableData = {};
  for (const key in data) {
    const value = data[key];
    value.sort((a, b) =>
      a.bad_row_percent < b.bad_row_percent
        ? 1
        : a.bad_row_percent > b.bad_row_percent
        ? -1
        : 0
    );
    sortedNestedTableData[key] = value;
  }
  return sortedNestedTableData;
};

const isCheckAccepted = (data, view_name) => {
  return data.find((ele) => ele.view_name == view_name)?.accept;
};

export const { useGetContentCheckRecordsQuery, useSetThresholdMutation } =
  contentCheckApiSlice;
