import React from "react";
import { act, screen } from "@testing-library/react";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";

import AnalyseChart from "./AnalyseChart";

let component = null;
beforeEach(async () => {
  await act(async () => {
    component = renderWithProviders(
      <Toolkit>
        <AnalyseChart />
      </Toolkit>
    );
  });
});

afterEach(() => {
  component.unmount();
});

describe("Renders Analyse Chart Component correctly", () => {
  test("Renders Analyse Chart Component correctly", async () => {
    expect(screen.getByTestId(/analyse-chart-page/i)).toBeInTheDocument();
  });
});
